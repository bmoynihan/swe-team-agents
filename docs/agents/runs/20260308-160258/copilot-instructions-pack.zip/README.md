# Path-Specific Copilot Instructions

This directory adds a small, layered instruction set on top of `.github/copilot-instructions.md` and `AGENTS.md`.

Why this helps in this repository:
- The repo already has strong global guidance, but many edits are highly path-specific.
- GitHub Copilot supports `.github/instructions/**/*.instructions.md` files for coding agent and code review.
- Smaller path-scoped files reduce instruction collisions and give the model better local guidance.

Design principles used here:
- Keep each file narrow and path-scoped.
- Reinforce supported GitHub conventions only.
- Prefer deterministic artifact ownership and least-privilege edits.
- Make instructions specific to this repository's Python, hooks, workflows, and agent-system structure.

Files in this pack:
- `agent-system-authoring.instructions.md`
- `agent-artifacts.instructions.md`
- `hooks-and-setup.instructions.md`
- `python.instructions.md`
- `python-tests.instructions.md`
- `code-review.instructions.md`

Notes:
- `code-review.instructions.md` is review-only and uses `excludeAgent: "coding-agent"`.
- Path-specific instruction files are additive with `.github/copilot-instructions.md`.

Source references used to shape this pack:
- GitHub support matrix for custom instructions
- GitHub repository instructions docs for `applyTo` and `excludeAgent`
- GitHub coding-agent setup workflow docs
- GitHub hooks docs
- GitHub customization library examples for workflow and testing instructions
- GitHub code review custom-instructions guidance
